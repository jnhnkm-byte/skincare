import streamlit as st
import json, os
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_products():
    with open(os.path.join(DATA_DIR, "products.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_purposes():
    with open(os.path.join(DATA_DIR, "purposes.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("🎯 목적별 화장품 탐색")
st.markdown("스킨케어 **사용 목적**별로 적합한 제품을 탐색합니다.")
st.markdown("---")

products = load_products()
purposes = load_purposes()

# ===== 목적 카드 표시 =====
st.subheader("📋 20가지 스킨케어 사용 목적")

for i in range(0, len(purposes), 4):
    cols = st.columns(4)
    for j, col in enumerate(cols):
        idx = i + j
        if idx < len(purposes):
            p = purposes[idx]
            count = sum(1 for prod in products if p["id"] in prod.get("purposes", []))
            with col:
                st.markdown(f"""
                <div style="border:1px solid #ddd; border-radius:8px; padding:10px; text-align:center; margin:3px 0; min-height:120px;">
                <h3>{p['icon']}</h3>
                <b>{p['name']}</b><br>
                <small style="color:#888;">{count}개 제품</small>
                </div>
                """, unsafe_allow_html=True)

st.markdown("---")

# ===== 목적 선택 =====
purpose_names = [f"{p['icon']} {p['name']}" for p in purposes]
selected_name = st.selectbox("🔍 탐색할 사용 목적을 선택하세요", purpose_names)

# 선택된 목적 찾기
selected_purpose = None
for p in purposes:
    if p["name"] in selected_name:
        selected_purpose = p
        break

if selected_purpose:
    st.markdown(f"## {selected_purpose['icon']} {selected_purpose['name']}")
    st.markdown(f"**{selected_purpose['description']}**")
    
    # 관련 정보
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### 🧪 핵심 성분")
        for ing in selected_purpose.get("key_ingredients", []):
            st.markdown(f"• {ing}")
    with col2:
        st.markdown("#### 🧴 관련 제품 유형")
        for cat in selected_purpose.get("related_categories", []):
            st.markdown(f"• {cat}")
    with col3:
        st.markdown("#### ⚠️ 관련 피부 고민")
        for c in selected_purpose.get("related_concerns", []):
            st.markdown(f"• {c}")
    
    st.markdown("---")
    
    # 해당 목적의 제품 목록
    matched_products = [p for p in products if selected_purpose["id"] in p.get("purposes", [])]
    
    # 하위 필터
    st.subheader(f"📦 관련 제품 ({len(matched_products)}개)")
    
    fcol1, fcol2, fcol3 = st.columns(3)
    with fcol1:
        filter_country = st.selectbox("국가", ["전체"] + sorted(set(p["country"] for p in matched_products)))
    with fcol2:
        filter_price = st.selectbox("가격대", ["전체", "저가", "중가", "고가", "프리미엄"])
    with fcol3:
        filter_cat = st.selectbox("제품 유형", ["전체"] + sorted(set(p["category"] for p in matched_products)))
    
    filtered = matched_products
    if filter_country != "전체":
        filtered = [p for p in filtered if p["country"] == filter_country]
    if filter_price != "전체":
        filtered = [p for p in filtered if p["price_range"] == filter_price]
    if filter_cat != "전체":
        filtered = [p for p in filtered if p["category"] == filter_cat]
    
    if not filtered:
        st.warning("조건에 맞는 제품이 없습니다.")
    else:
        # 카드 형태 표시
        for i in range(0, len(filtered), 3):
            cols = st.columns(3)
            for j, col in enumerate(cols):
                idx = i + j
                if idx < len(filtered):
                    p = filtered[idx]
                    flag = {"한국":"🇰🇷","일본":"🇯🇵","프랑스":"🇫🇷","미국":"🇺🇸","독일":"🇩🇪","영국":"🇬🇧","스위스":"🇨🇭"}.get(p["country"],"🌍")
                    price_icon = {"저가":"🟢","중가":"🔵","고가":"🟠","프리미엄":"🟣"}.get(p["price_range"],"⚪")
                    
                    with col:
                        st.markdown(f"""
                        <div style="border:1px solid #e0e0e0; border-radius:10px; padding:12px; margin:4px 0; min-height:180px;">
                        <b>{flag} {p['name']}</b><br>
                        <small>{p['brand']} | {price_icon} {p['price_range']} | {p['category']}</small><br><br>
                        <small style="color:#555;">{p['description']}</small><br><br>
                        <small><b>성분:</b> {', '.join(p['key_ingredients'][:3])}</small>
                        </div>
                        """, unsafe_allow_html=True)
        
        # 테이블 뷰
        st.markdown("---")
        with st.expander("📊 테이블 보기"):
            df_data = []
            for p in filtered:
                flag = {"한국":"🇰🇷","일본":"🇯🇵","프랑스":"🇫🇷","미국":"🇺🇸","독일":"🇩🇪","영국":"🇬🇧","스위스":"🇨🇭"}.get(p["country"],"🌍")
                df_data.append({
                    "제품명": p["name"],
                    "브랜드": p["brand"],
                    "국가": f"{flag} {p['country']}",
                    "유형": p["category"],
                    "가격대": p["price_range"],
                    "핵심성분": ", ".join(p["key_ingredients"][:3]),
                })
            st.dataframe(pd.DataFrame(df_data), use_container_width=True, hide_index=True)
    
    # ===== 목적 조합 추천 =====
    st.markdown("---")
    st.subheader("🔄 목적 조합 추천")
    st.markdown("여러 목적을 동시에 충족하는 제품을 찾아보세요.")
    
    other_purposes = [f"{p['icon']} {p['name']}" for p in purposes if p["id"] != selected_purpose["id"]]
    additional = st.multiselect("추가 목적 선택", other_purposes)
    
    if additional:
        additional_ids = []
        for a in additional:
            for p in purposes:
                if p["name"] in a:
                    additional_ids.append(p["id"])
                    break
        
        all_required = [selected_purpose["id"]] + additional_ids
        combo_products = [p for p in products if all(pid in p.get("purposes", []) for pid in all_required)]
        
        if combo_products:
            st.success(f"✅ {len(combo_products)}개 제품이 모든 목적을 충족합니다!")
            for p in combo_products[:10]:
                flag = {"한국":"🇰🇷","일본":"🇯🇵","프랑스":"🇫🇷","미국":"🇺🇸","독일":"🇩🇪","영국":"🇬🇧","스위스":"🇨🇭"}.get(p["country"],"🌍")
                purposes_str = " ".join(
                    next((pur["icon"] for pur in purposes if pur["id"] == pid), "") 
                    for pid in all_required
                )
                st.markdown(f"• {flag} **{p['brand']}** {p['name']} — {p['category']} ({p['price_range']}) {purposes_str}")
        else:
            st.warning("모든 목적을 동시에 충족하는 제품이 없습니다. 목적을 줄여보세요.")
