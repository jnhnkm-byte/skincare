import streamlit as st
import json, os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_ingredients():
    with open(os.path.join(DATA_DIR, "ingredients.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_skin_types():
    with open(os.path.join(DATA_DIR, "skin_types.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("📖 화장품 성분 사전")
st.markdown("화장품 주요 성분의 효능, 안전성, 조합 가이드를 확인하세요.")

ingredients = load_ingredients()
skin_types_db = load_skin_types()
skin_type = st.session_state.get("skin_type")

# --- 검색 ---
st.markdown("---")
search = st.text_input("🔍 성분 검색 (한글 또는 영문)", placeholder="예: 레티놀, Niacinamide")

# --- 카테고리 필터 ---
all_categories = sorted(set(ing["category"] for ing in ingredients))
sel_cats = st.multiselect("📂 카테고리 필터", all_categories, default=all_categories)

# --- EWG 필터 ---
ewg_filter = st.slider("🛡️ EWG 안전 등급 필터 (이하만 표시)", 1, 10, 10)

st.markdown("---")

# --- 필터링 ---
filtered = ingredients
if search:
    search_lower = search.lower()
    filtered = [ing for ing in filtered 
                if search_lower in ing["name_ko"].lower() 
                or search_lower in ing["name_en"].lower()
                or search_lower in ing.get("category", "").lower()]
filtered = [ing for ing in filtered if ing["category"] in sel_cats]
filtered = [ing for ing in filtered if ing.get("ewg_grade", 1) <= ewg_filter]

# --- 피부 유형별 적합/부적합 표시 ---
skin_prefix = skin_type[:2] if skin_type else None

st.subheader(f"📋 성분 목록 ({len(filtered)}개)")

if not filtered:
    st.info("조건에 맞는 성분이 없습니다.")
else:
    for ing in filtered:
        # 적합/부적합 판단
        is_suitable = True
        is_unsuitable = False
        unsuitability_note = ""
        
        if skin_prefix:
            for us in ing.get("unsuitable_skin_types", []):
                base = us.replace("(고농도)", "").replace("(저농도)", "").strip()
                if base == skin_prefix:
                    is_unsuitable = True
                    unsuitability_note = us
                    break
            
            suitable_check = any(skin_prefix in st for st in ing.get("suitable_skin_types", []))
            if not suitable_check and not is_unsuitable:
                is_suitable = False
        
        # 아이콘 결정
        ewg = ing.get("ewg_grade", 1)
        if ewg <= 2:
            ewg_icon = "🟢"
        elif ewg <= 6:
            ewg_icon = "🟡"
        else:
            ewg_icon = "🔴"
        
        if is_unsuitable:
            suitability_icon = "🚫"
            suitability_text = f"내 피부({skin_type})에 부적합"
        elif is_suitable and skin_type:
            suitability_icon = "✅"
            suitability_text = f"내 피부({skin_type})에 적합"
        elif skin_type:
            suitability_icon = "➖"
            suitability_text = "해당 없음"
        else:
            suitability_icon = ""
            suitability_text = ""
        
        header = f"{suitability_icon} {ing['name_ko']} ({ing['name_en']}) {ewg_icon} EWG {ewg}"
        
        with st.expander(header):
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.markdown(f"**분류**: {ing['category']}")
                st.markdown(f"**효능**: {ing['effects']}")
                
                if skin_type and suitability_text:
                    if is_unsuitable:
                        st.error(f"**{suitability_text}** ({unsuitability_note})")
                    else:
                        st.success(f"**{suitability_text}**")
                
                if ing.get("caution"):
                    st.warning(f"⚠️ **주의사항**: {ing['caution']}")
            
            with col2:
                st.metric("EWG 등급", f"{ewg}/10")
                if ewg <= 2:
                    st.caption("안전")
                elif ewg <= 6:
                    st.caption("보통")
                else:
                    st.caption("위험")
            
            # 적합 피부 타입
            st.markdown("---")
            sub1, sub2 = st.columns(2)
            with sub1:
                st.markdown("**✅ 적합 피부 유형**")
                for st_ in ing.get("suitable_skin_types", []):
                    st.markdown(f"• {st_}")
            with sub2:
                st.markdown("**🚫 부적합 피부 유형**")
                unsuitable = ing.get("unsuitable_skin_types", [])
                if unsuitable:
                    for us in unsuitable:
                        st.markdown(f"• {us}")
                else:
                    st.markdown("• 없음 (모든 피부에 사용 가능)")
            
            # 적합 고민
            concerns_list = ing.get("suitable_concerns", [])
            if concerns_list:
                st.markdown(f"**🎯 효과적인 고민**: {', '.join(concerns_list)}")
            
            # 조합 가이드
            st.markdown("---")
            comb1, comb2 = st.columns(2)
            with comb1:
                st.markdown("**👍 좋은 조합**")
                good = ing.get("good_combinations", [])
                if good:
                    for g in good:
                        st.markdown(f"• ✅ {g}")
                else:
                    st.markdown("• 정보 없음")
            
            with comb2:
                st.markdown("**👎 나쁜 조합 (함께 사용 금지)**")
                bad = ing.get("bad_combinations", [])
                if bad:
                    for b in bad:
                        st.markdown(f"• ❌ {b}")
                else:
                    st.markdown("• 없음")

# --- 성분 조합 체커 ---
st.markdown("---")
st.subheader("🧪 성분 조합 체커")
st.markdown("두 가지 성분을 선택하면 함께 사용해도 되는지 확인합니다.")

ing_names = [ing["name_ko"] for ing in ingredients]
col_a, col_b = st.columns(2)
with col_a:
    ing1 = st.selectbox("첫 번째 성분", ing_names, index=0)
with col_b:
    ing2 = st.selectbox("두 번째 성분", ing_names, index=1)

if st.button("🔬 조합 확인", type="primary", use_container_width=True):
    if ing1 == ing2:
        st.info("같은 성분입니다.")
    else:
        ing1_data = next(i for i in ingredients if i["name_ko"] == ing1)
        ing2_data = next(i for i in ingredients if i["name_ko"] == ing2)
        
        # 상호 체크
        conflict_found = False
        
        for bad in ing1_data.get("bad_combinations", []):
            bad_base = bad.split("(")[0].strip()
            if bad_base in ing2 or ing2 in bad_base or bad_base in ing2_data.get("name_en", ""):
                st.error(f"❌ **사용 금지 조합!**\n\n{ing1} + {ing2}: {bad}")
                conflict_found = True
        
        for bad in ing2_data.get("bad_combinations", []):
            bad_base = bad.split("(")[0].strip()
            if bad_base in ing1 or ing1 in bad_base or bad_base in ing1_data.get("name_en", ""):
                st.error(f"❌ **사용 금지 조합!**\n\n{ing2} + {ing1}: {bad}")
                conflict_found = True
        
        # 좋은 조합 체크
        good_found = False
        for good in ing1_data.get("good_combinations", []):
            if good in ing2 or ing2 in good:
                st.success(f"✅ **좋은 조합!** {ing1}과(와) {ing2}은(는) 시너지 효과가 있습니다.")
                good_found = True
                break
        
        if not good_found:
            for good in ing2_data.get("good_combinations", []):
                if good in ing1 or ing1 in good:
                    st.success(f"✅ **좋은 조합!** {ing2}과(와) {ing1}은(는) 시너지 효과가 있습니다.")
                    good_found = True
                    break
        
        if not conflict_found and not good_found:
            st.info(f"ℹ️ {ing1}과(와) {ing2}은(는) 특별한 상호작용 정보가 없습니다. 일반적으로 함께 사용 가능합니다.")

# --- 하단 가이드 ---
st.markdown("---")
st.markdown("### 📚 EWG 안전 등급 안내")
st.markdown("""
| 등급 | 표시 | 의미 |
|------|------|------|
| 1~2 | 🟢 | **안전** — 대부분의 사람에게 안전 |
| 3~6 | 🟡 | **보통** — 일부 주의 필요, 민감 피부 패치테스트 권장 |
| 7~10 | 🔴 | **위험** — 사용 주의, 전문가 상담 권장 |
""")

st.markdown("""
### 💡 성분 사용 팁
- **레티놀 + 비타민C**: 동시 사용 시 자극 가능 → 아침/저녁 분리 사용 권장
- **AHA/BHA + 레티놀**: 동시 사용 금지 → 격일 사용 또는 시간 분리
- **비타민C + 페룰산 + 비타민E**: 최강 항산화 트리오, 함께 사용 추천
- **나이아신아마이드**: 거의 모든 성분과 호환, 만능 성분
- **새로운 성분은 항상 패치테스트 후 사용하세요!**
""")

st.caption("※ EWG(Environmental Working Group) 등급은 참고용이며, 개인의 피부 반응은 다를 수 있습니다.")
