import streamlit as st
import json, os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_body_parts():
    with open(os.path.join(DATA_DIR, "body_parts.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_ingredients():
    with open(os.path.join(DATA_DIR, "ingredients.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("🦶 부위별 피부 분석")
st.markdown("신체 부위별로 피부 특성이 다릅니다. 부위를 선택하면 특징과 관리법을 확인할 수 있습니다.")
st.markdown("---")

body_parts = load_body_parts()
ingredients = load_ingredients()

part_names = [bp["name"] for bp in body_parts]
selected_name = st.selectbox("📍 분석할 부위를 선택하세요", part_names)

selected = next(bp for bp in body_parts if bp["name"] == selected_name)

st.markdown(f"## {selected['name']}")

col1, col2 = st.columns(2)
with col1:
    st.markdown("#### 📋 기본 정보")
    st.markdown(f"• **피부 두께**: {selected['skin_thickness']}")
    st.markdown(f"• **피지선 분포**: {selected['sebaceous_glands']}")

with col2:
    st.markdown("#### 🔧 특수 관리법")
    st.markdown(selected['special_care'])

st.markdown("---")

st.markdown("#### ⚠️ 이 부위의 흔한 피부 문제")
issue_cols = st.columns(min(len(selected["common_issues"]), 5))
for i, issue in enumerate(selected["common_issues"]):
    with issue_cols[i % len(issue_cols)]:
        st.info(f"**{issue}**")

st.markdown("#### 🧴 적합한 제품 유형")
for pt in selected["suitable_product_types"]:
    st.markdown(f"• {pt}")

st.markdown("---")

# 고민 선택
all_concerns = [
    "건조", "여드름", "색소침착", "주름", "각질", "가려움", "민감", "모공",
    "탄력저하", "튼살", "지루성피부염", "아토피", "무좀", "냄새", "홍조",
    "블랙헤드", "다크서클", "붓기", "갈라짐", "칙칙함", "유분"
]

st.subheader("🎯 이 부위의 피부 고민을 선택하세요")
selected_concerns = st.multiselect("복수 선택 가능", all_concerns, 
                                     default=[c for c in selected["common_issues"] if c in all_concerns])

if selected_concerns:
    # 세션 저장
    st.session_state["selected_body_part"] = selected["id"]
    st.session_state["selected_concerns"] = selected_concerns
    
    st.markdown("---")
    st.subheader("✅ 선택한 고민에 권장되는 성분")
    
    matched_ingredients = []
    for ing in ingredients:
        matching = [c for c in selected_concerns if c in ing.get("suitable_concerns", [])]
        if matching:
            matched_ingredients.append((ing, matching))
    
    matched_ingredients.sort(key=lambda x: len(x[1]), reverse=True)
    
    for ing, matches in matched_ingredients[:10]:
        with st.expander(f"🧪 {ing['name_ko']} ({ing['name_en']}) — 매칭: {', '.join(matches)}"):
            st.markdown(f"**분류**: {ing['category']}")
            st.markdown(f"**효능**: {ing['effects']}")
            st.markdown(f"**EWG 안전 등급**: {'🟢' if ing['ewg_grade'] <= 2 else '🟡' if ing['ewg_grade'] <= 6 else '🔴'} {ing['ewg_grade']}/10")
            if ing.get("caution"):
                st.markdown(f"**⚠️ 주의사항**: {ing['caution']}")
    
    st.markdown("---")
    st.info("💡 **화장품 추천** 페이지로 이동하면 이 고민에 맞는 제품을 확인할 수 있습니다!")
