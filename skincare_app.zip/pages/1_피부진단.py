import streamlit as st
import json, os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_skin_types():
    with open(os.path.join(DATA_DIR, "skin_types.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("🔬 피부 진단")
st.markdown("Baumann Skin Type 분류 체계 기반 자가 진단입니다. 각 질문에 솔직하게 답해 주세요.")
st.markdown("---")

# ===== Fitzpatrick =====
st.subheader("Step 0. 피부색 유형 (Fitzpatrick)")
fitz = st.radio("햇빛에 노출되었을 때 피부 반응은?", [
    "I - 항상 화상, 태닝 안됨 (매우 밝은 피부)",
    "II - 쉽게 화상, 약간 태닝 (밝은 피부)",
    "III - 가끔 화상, 점진적 태닝 (중간 피부)",
    "IV - 거의 화상 없음, 쉽게 태닝 (약간 어두운 피부)",
    "V - 화상 드뭄, 진한 태닝 (어두운 피부)",
    "VI - 화상 없음 (매우 어두운 피부)",
], index=2)
fitzpatrick_type = fitz.split(" - ")[0]

# ===== D/O 건성 vs 지성 =====
st.markdown("---")
st.subheader("Step 1. 건성(D) vs 지성(O)")
do_scores = []

q1 = st.radio("세안 후 아무것도 바르지 않고 2시간 뒤 피부는?", [
    "당기고 건조함 (1점)", "보통 (2점)", "T존에 유분이 올라옴 (3점)", "전체적으로 번들거림 (4점)"
])
do_scores.append(int(q1.split("(")[1][0]))

q2 = st.radio("낮 동안 피부의 유분 상태는?", [
    "하루 종일 건조 (1점)", "약간 유분 (2점)", "T존 중심 유분 (3점)", "전체 유분 과다 (4점)"
])
do_scores.append(int(q2.split("(")[1][0]))

q3 = st.radio("블로팅 페이퍼를 T존에 대면?", [
    "유분 거의 없음 (1점)", "약간의 유분 (2점)", "뚜렷한 유분 (3점)", "즉시 투명해짐 (4점)"
])
do_scores.append(int(q3.split("(")[1][0]))

q4 = st.radio("모공 크기는?", [
    "거의 안보임 (1점)", "코 주변만 약간 (2점)", "T존 전체 보임 (3점)", "얼굴 전체 넓음 (4점)"
])
do_scores.append(int(q4.split("(")[1][0]))

q5 = st.radio("여드름/뾰루지가 나는 빈도는?", [
    "거의 안남 (1점)", "가끔 (2점)", "자주 (3점)", "항상 있음 (4점)"
])
do_scores.append(int(q5.split("(")[1][0]))

# ===== S/R 민감 vs 저항 =====
st.markdown("---")
st.subheader("Step 2. 민감(S) vs 저항(R)")
sr_scores = []

q6 = st.radio("새로운 화장품 사용 시 반응은?", [
    "자주 트러블/따가움 (4점)", "가끔 반응 (3점)", "드물게 반응 (2점)", "거의 반응 없음 (1점)"
])
sr_scores.append(int(q6.split("(")[1][0]))

q7 = st.radio("피부에 홍조/붉어짐이 나타나는 빈도는?", [
    "매우 자주 (4점)", "자주 (3점)", "가끔 (2점)", "거의 없음 (1점)"
])
sr_scores.append(int(q7.split("(")[1][0]))

q8 = st.radio("아토피/습진/알레르기 경험은?", [
    "현재 있음 (4점)", "과거에 있었음 (3점)", "가족력만 있음 (2점)", "전혀 없음 (1점)"
])
sr_scores.append(int(q8.split("(")[1][0]))

q9 = st.radio("자극적인 성분(레티놀, AHA 등) 사용 시?", [
    "즉시 반응 (4점)", "빈번한 자극 (3점)", "가끔 자극 (2점)", "문제 없음 (1점)"
])
sr_scores.append(int(q9.split("(")[1][0]))

q10 = st.radio("향수/향료가 포함된 제품 사용 시?", [
    "항상 자극 (4점)", "자주 자극 (3점)", "가끔 자극 (2점)", "문제 없음 (1점)"
])
sr_scores.append(int(q10.split("(")[1][0]))

# ===== P/N 색소침착 vs 비색소 =====
st.markdown("---")
st.subheader("Step 3. 색소침착(P) vs 비색소(N)")
pn_scores = []

q11 = st.radio("기미/잡티/주근깨가 있나요?", [
    "많음 (4점)", "중간 (3점)", "약간 (2점)", "거의 없음 (1점)"
])
pn_scores.append(int(q11.split("(")[1][0]))

q12 = st.radio("상처/여드름 자국이 색소로 남는 편인가요?", [
    "항상 진하게 남음 (4점)", "자주 남음 (3점)", "가끔 남음 (2점)", "거의 안남음 (1점)"
])
pn_scores.append(int(q12.split("(")[1][0]))

q13 = st.radio("햇빛에 노출 후 색소 변화는?", [
    "쉽게 검어지고 잘 안돌아옴 (4점)", "검어지지만 서서히 회복 (3점)", "약간 변화 (2점)", "변화 거의 없음 (1점)"
])
pn_scores.append(int(q13.split("(")[1][0]))

q14 = st.radio("눈가/입가 색소침착(다크닝)이 있나요?", [
    "뚜렷함 (4점)", "어느 정도 (3점)", "약간 (2점)", "없음 (1점)"
])
pn_scores.append(int(q14.split("(")[1][0]))

# ===== W/T 주름 vs 탄력 =====
st.markdown("---")
st.subheader("Step 4. 주름(W) vs 탄력(T)")
wt_scores = []

q15 = st.radio("이마/눈가에 잔주름이 보이나요?", [
    "뚜렷한 주름 (4점)", "잔주름 있음 (3점)", "표정 지을 때만 (2점)", "거의 없음 (1점)"
])
wt_scores.append(int(q15.split("(")[1][0]))

q16 = st.radio("피부를 손으로 잡았다 놓으면 탄력은?", [
    "느리게 돌아옴 (4점)", "약간 느림 (3점)", "금방 돌아옴 (2점)", "즉시 돌아옴 (1점)"
])
wt_scores.append(int(q16.split("(")[1][0]))

q17 = st.radio("부모님의 나이 대비 주름 상태는?", [
    "매우 많은 편 (4점)", "보통 (3점)", "적은 편 (2점)", "거의 없음 (1점)"
])
wt_scores.append(int(q17.split("(")[1][0]))

q18 = st.radio("자외선 차단제를 꾸준히 사용해 왔나요?", [
    "거의 안바름 (4점)", "가끔 바름 (3점)", "자주 바름 (2점)", "항상 바름 (1점)"
])
wt_scores.append(int(q18.split("(")[1][0]))

q19 = st.radio("흡연 경험은?", [
    "현재 흡연 중 (4점)", "과거 흡연 (3점)", "간접 흡연 노출 (2점)", "전혀 없음 (1점)"
])
wt_scores.append(int(q19.split("(")[1][0]))

# ===== 진단 결과 =====
st.markdown("---")
if st.button("🔬 피부 유형 진단하기", type="primary", use_container_width=True):
    
    do_avg = sum(do_scores) / len(do_scores)
    sr_avg = sum(sr_scores) / len(sr_scores)
    pn_avg = sum(pn_scores) / len(pn_scores)
    wt_avg = sum(wt_scores) / len(wt_scores)
    
    d_or_o = "O" if do_avg >= 2.5 else "D"
    s_or_r = "S" if sr_avg >= 2.5 else "R"
    p_or_n = "P" if pn_avg >= 2.5 else "N"
    w_or_t = "W" if wt_avg >= 2.5 else "T"
    
    skin_type_code = d_or_o + s_or_r + p_or_n + w_or_t
    
    # 세션 저장
    st.session_state["skin_type"] = skin_type_code
    st.session_state["fitzpatrick"] = fitzpatrick_type
    
    # 결과 표시
    skin_types = load_skin_types()
    matched = next((s for s in skin_types if s["type_code"] == skin_type_code), None)
    
    st.success(f"## 🎯 당신의 Baumann 피부 유형: **{skin_type_code}**")
    st.info(f"**Fitzpatrick 피부색 유형: {fitzpatrick_type}**")
    
    if matched:
        st.markdown(f"### {matched['name_ko']}")
        st.markdown(matched["description"])
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("#### 🔍 피부 특징")
            for c in matched["characteristics"]:
                st.markdown(f"• {c}")
            
            st.markdown("#### ✅ 권장 성분")
            for ing in matched["recommended_ingredients"]:
                st.markdown(f"• {ing}")
        
        with col2:
            st.markdown("#### ⚠️ 주요 고민")
            for c in matched["common_concerns"]:
                st.markdown(f"• {c}")
            
            st.markdown("#### ❌ 피해야 할 성분")
            for ing in matched["avoid_ingredients"]:
                st.markdown(f"• {ing}")
        
        st.markdown("---")
        st.markdown("#### 📊 진단 상세 점수")
        score_cols = st.columns(4)
        labels = [
            (f"건성↔지성", do_avg, "건성(D)" if d_or_o == "D" else "지성(O)"),
            (f"민감↔저항", sr_avg, "민감(S)" if s_or_r == "S" else "저항(R)"),
            (f"색소↔비색소", pn_avg, "색소(P)" if p_or_n == "P" else "비색소(N)"),
            (f"주름↔탄력", wt_avg, "주름(W)" if w_or_t == "W" else "탄력(T)"),
        ]
        for col, (label, score, result) in zip(score_cols, labels):
            with col:
                st.metric(label, f"{score:.1f} / 4.0", result)
        
        st.markdown("---")
        st.info("💡 **화장품 추천** 페이지로 이동하면 이 진단 결과에 맞는 맞춤 제품을 확인할 수 있습니다!")
    else:
        st.warning("진단 결과 매칭에 실패했습니다. 다시 시도해 주세요.")
