import streamlit as st
import json, os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_factors():
    with open(os.path.join(DATA_DIR, "skin_factors.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("🌍 환경 및 생활 종합 분석")
st.markdown("피부에 영향을 미치는 **환경, 개인 특성, 생활습관, 건강 요인**을 종합 분석합니다.")
st.markdown("이 정보는 화장품 추천 시 반영되어 더 정확한 맞춤 추천을 제공합니다.")
st.markdown("---")

factors = load_factors()

all_selections = {}
all_tips = {}

for category_key, category in factors.items():
    st.subheader(f"{'🌿' if category_key=='environmental' else '👤' if category_key=='personal' else '🏃' if category_key=='lifestyle' else '🏥'} {category['name']}")
    
    factor_items = category["factors"]
    
    # 2열 레이아웃
    keys = list(factor_items.keys())
    for i in range(0, len(keys), 2):
        cols = st.columns(2)
        for j, col in enumerate(cols):
            idx = i + j
            if idx < len(keys):
                fkey = keys[idx]
                fdata = factor_items[fkey]
                with col:
                    options = list(fdata["options"].keys())
                    # 기본값 설정
                    default_idx = 0
                    if fkey == "season":
                        import datetime
                        month = datetime.datetime.now().month
                        if month in [3,4,5]: default_idx = 0
                        elif month in [6,7,8]: default_idx = 1
                        elif month in [9,10,11]: default_idx = 2
                        else: default_idx = 3
                    elif fkey == "age_group":
                        default_idx = 3  # 40대
                    elif fkey == "gender":
                        default_idx = 0  # 남성
                    elif len(options) >= 3:
                        default_idx = len(options) // 2  # 중간값
                    
                    selected = st.selectbox(
                        fdata["name"],
                        options,
                        index=min(default_idx, len(options)-1),
                        key=f"factor_{fkey}"
                    )
                    
                    # 선택된 옵션 설명 표시
                    desc = fdata["options"][selected]
                    st.caption(f"💡 {desc}")
                    
                    all_selections[fkey] = selected
                    
                    # 계절별 팁이 있으면 저장
                    if "skincare_tip" in fdata and selected in fdata["skincare_tip"]:
                        all_tips[fkey] = fdata["skincare_tip"][selected]
    
    st.markdown("---")

# ===== 분석 결과 =====
if st.button("📊 종합 피부 환경 분석하기", type="primary", use_container_width=True):
    
    # 세션에 저장
    st.session_state["skin_factors"] = all_selections
    
    st.success("✅ 종합 피부 환경 분석이 완료되었습니다!")
    
    # ===== 종합 리스크 점수 =====
    st.subheader("📊 피부 환경 종합 리포트")
    
    # 환경 리스크 계산
    env_risk = 0
    env_details = []
    
    # 계절
    season = all_selections.get("season", "")
    if season == "겨울":
        env_risk += 3
        env_details.append("❄️ 겨울: 극건조 환경, 고보습 필요")
    elif season == "여름":
        env_risk += 2
        env_details.append("☀️ 여름: 피지 증가+자외선 최대, 피지조절+차단 필수")
    elif season == "봄":
        env_risk += 2
        env_details.append("🌸 봄: 황사·꽃가루 민감, 진정 케어 강화")
    else:
        env_risk += 1
        env_details.append("🍂 가을: 건조해지는 환절기, 보습 전환 시기")
    
    # 온도
    temp = all_selections.get("temperature", "")
    if "한랭" in temp:
        env_risk += 2; env_details.append("🥶 한랭 환경: 혈관 수축, 건조 심화")
    elif "고온" in temp:
        env_risk += 2; env_details.append("🔥 고온 환경: 피지·땀 증가")
    
    # 습도
    humid = all_selections.get("humidity", "")
    if "건조" in humid:
        env_risk += 2; env_details.append("💨 저습도: 경피수분손실 증가")
    elif "다습" in humid:
        env_risk += 1; env_details.append("💧 고습도: 모공 막힘·세균 증식 주의")
    
    # UV
    uv = all_selections.get("uv_exposure", "")
    if "높음" in uv:
        env_risk += 3; env_details.append("☀️ 자외선 고노출: SPF50+ 필수, 2시간마다 재도포")
    elif "보통" in uv:
        env_risk += 1
    
    # 대기오염
    pollution = all_selections.get("air_pollution", "")
    if "나쁨" in pollution:
        env_risk += 2; env_details.append("😷 대기오염: 이중세안+항산화 필수")
    
    # 블루라이트
    blue = all_selections.get("blue_light", "")
    if "많음" in blue:
        env_risk += 1; env_details.append("📱 블루라이트 과다: 항산화 세럼 권장")
    
    # 생활습관 리스크
    life_risk = 0
    life_details = []
    
    sleep = all_selections.get("sleep_hours", "")
    if "5시간 미만" in sleep:
        life_risk += 3; life_details.append("😴 수면 부족: 피부 재생 심각 저하")
    elif "5~7" in sleep:
        life_risk += 1
    
    stress = all_selections.get("stress_level", "")
    if "매우 높음" in stress:
        life_risk += 3; life_details.append("😰 극심한 스트레스: 피부 장벽 손상 위험")
    elif "높음" in stress:
        life_risk += 2; life_details.append("😟 높은 스트레스: 피지 증가, 여드름 악화")
    
    water = all_selections.get("water_intake", "")
    if "0.5L 미만" in water:
        life_risk += 2; life_details.append("🥤 수분 섭취 극부족: 피부 탈수")
    elif "0.5~1L" in water:
        life_risk += 1; life_details.append("🥤 수분 섭취 부족")
    
    smoking = all_selections.get("smoking", "")
    if "흡연" in smoking and "전자" not in smoking:
        life_risk += 3; life_details.append("🚬 흡연: 콜라겐 파괴, 피부 노화 가속")
    elif "전자" in smoking:
        life_risk += 1
    
    alcohol = all_selections.get("alcohol", "")
    if "3회 이상" in alcohol:
        life_risk += 2; life_details.append("🍺 잦은 음주: 탈수·홍조·노화 가속")
    
    diet = all_selections.get("diet", "")
    if "고당" in diet:
        life_risk += 2; life_details.append("🍔 고당·고지방: 피지 증가, 당화 노화")
    
    sleep_time = all_selections.get("sleep_time", "")
    if "24시 이후" in sleep_time:
        life_risk += 1; life_details.append("🌙 늦은 취침: 피부 재생 골든타임 놓침")
    
    exercise = all_selections.get("exercise", "")
    if "거의 안함" in exercise:
        life_risk += 1; life_details.append("🏃 운동 부족: 혈액순환·신진대사 저하")
    
    mask = all_selections.get("mask_wearing", "")
    if "자주" in mask:
        life_risk += 1; life_details.append("😷 마스크 장시간: 마스크네·마찰 자극")
    
    # 건강 리스크
    health_risk = 0
    health_details = []
    
    condition = all_selections.get("skin_conditions", "")
    if condition != "없음":
        health_risk += 2; health_details.append(f"🏥 기존 피부질환: {condition}")
    
    meds = all_selections.get("medications", "")
    if meds != "없음":
        health_risk += 2; health_details.append(f"💊 복용 약물: {meds} — 성분 제한 있을 수 있음")
    
    allergy = all_selections.get("allergies", "")
    if allergy != "없음":
        health_risk += 1; health_details.append(f"⚠️ 알레르기: {allergy}")
    
    hormonal = all_selections.get("hormonal_status", "")
    if hormonal != "정상":
        health_risk += 1; health_details.append(f"🔄 호르몬 상태: {hormonal}")
    
    # 개인 특성에서 추가 정보 추출
    age = all_selections.get("age_group", "")
    pore = all_selections.get("pore_size", "")
    sebum = all_selections.get("sebum_level", "")
    moisture = all_selections.get("moisture_level", "")
    
    # ===== 시각화 =====
    total_risk = env_risk + life_risk + health_risk
    max_risk = 30
    risk_pct = min(total_risk / max_risk, 1.0)
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("환경 리스크", f"{env_risk}/15", "주의" if env_risk >= 8 else "양호")
    with col2:
        st.metric("생활습관 리스크", f"{life_risk}/15", "주의" if life_risk >= 8 else "양호")
    with col3:
        st.metric("건강 리스크", f"{health_risk}/10", "주의" if health_risk >= 5 else "양호")
    with col4:
        risk_label = "🟢 양호" if total_risk < 10 else "🟡 주의" if total_risk < 20 else "🔴 위험"
        st.metric("종합 리스크", f"{total_risk}/{max_risk}", risk_label)
    
    st.progress(1.0 - risk_pct)
    
    # 상세 리포트
    if env_details:
        with st.expander("🌿 환경 요인 상세", expanded=True):
            for d in env_details:
                st.markdown(f"• {d}")
    
    if life_details:
        with st.expander("🏃 생활습관 요인 상세", expanded=True):
            for d in life_details:
                st.markdown(f"• {d}")
    
    if health_details:
        with st.expander("🏥 건강 요인 상세", expanded=True):
            for d in health_details:
                st.markdown(f"• {d}")
    
    # 계절별 맞춤 팁
    if all_tips:
        st.subheader("🗓️ 현재 계절 맞춤 스킨케어 팁")
        for key, tip in all_tips.items():
            st.info(f"💡 {tip}")
    
    # 나이별 핵심 케어
    st.subheader(f"👤 {age} 핵심 케어 포인트")
    age_data = factors["personal"]["factors"]["age_group"]["options"].get(age, "")
    st.markdown(age_data)
    
    # 피부 상태 요약
    st.subheader("📋 나의 피부 상태 요약")
    summary_data = {
        "항목": ["모공 크기", "피지 분비량", "수분감", "피부 두께", "성별", "호르몬 상태"],
        "현재 상태": [
            all_selections.get("pore_size", "-"),
            all_selections.get("sebum_level", "-"),
            all_selections.get("moisture_level", "-"),
            all_selections.get("skin_thickness", "-"),
            all_selections.get("gender", "-"),
            all_selections.get("hormonal_status", "-"),
        ]
    }
    import pandas as pd
    st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)
    
    # 권장 vs 주의 성분
    st.subheader("✅ 환경 분석 기반 권장 성분")
    recommended = set()
    cautions = set()
    
    if "겨울" in season or "건조" in humid or "매우 건조" in moisture:
        recommended.update(["세라마이드", "히알루론산", "시어버터", "스쿠알란", "판테놀"])
    if "여름" in season or "많음" in sebum or "매우 많음" in sebum:
        recommended.update(["나이아신아마이드", "살리실산", "징크", "녹차추출물", "티트리"])
    if "높음" in uv:
        recommended.update(["비타민C", "비타민E", "페룰산", "미네랄선크림"])
    if "나쁨" in pollution:
        recommended.update(["비타민C", "비타민E", "녹차추출물", "센텔라"])
    if "높음" in stress or "매우 높음" in stress:
        recommended.update(["센텔라", "판테놀", "알로에", "마데카소사이드"])
    if "30대" in age or "40대" in age or "50대" in age or "60대" in age:
        recommended.update(["레티놀", "펩타이드", "아데노신", "콜라겐"])
    if "봄" in season:
        recommended.update(["센텔라", "알로에", "판테놀", "감초추출물"])
    
    if hormonal == "임신·수유 중":
        cautions.update(["레티놀", "살리실산", "벤조일퍼옥사이드"])
        recommended.discard("레티놀"); recommended.discard("살리실산")
    if condition == "주사(로사세아)":
        cautions.update(["알코올", "향료", "멘톨", "유칼립투스"])
    if "이소트레티노인" in meds:
        cautions.update(["AHA", "BHA", "레티놀", "비타민C(고농도)"])
    
    rcol, ccol = st.columns(2)
    with rcol:
        st.markdown("**✅ 권장 성분**")
        for r in sorted(recommended):
            st.markdown(f"• 🟢 {r}")
    with ccol:
        st.markdown("**⚠️ 주의/금지 성분**")
        if cautions:
            for c in sorted(cautions):
                st.markdown(f"• 🔴 {c}")
        else:
            st.markdown("• 특별한 제한 없음")
    
    # 세션에 권장/주의 성분 저장
    st.session_state["recommended_ingredients"] = list(recommended)
    st.session_state["caution_ingredients"] = list(cautions)
    st.session_state["env_risk"] = env_risk
    st.session_state["life_risk"] = life_risk
    st.session_state["health_risk"] = health_risk
    st.session_state["age_group"] = age
    st.session_state["season"] = season
    
    st.markdown("---")
    st.info("💡 이 분석 결과는 **화장품 추천** 페이지에 자동 반영됩니다. 피부 진단(Baumann)도 함께 하시면 더 정확한 추천을 받을 수 있습니다!")
