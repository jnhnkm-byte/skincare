import streamlit as st
import json, os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

@st.cache_data
def load_products():
    with open(os.path.join(DATA_DIR, "products.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_ingredients():
    with open(os.path.join(DATA_DIR, "ingredients.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_skin_types():
    with open(os.path.join(DATA_DIR, "skin_types.json"), "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_body_parts():
    with open(os.path.join(DATA_DIR, "body_parts.json"), "r", encoding="utf-8") as f:
        return json.load(f)

st.title("💄 맞춤 화장품 추천")

products = load_products()
ingredients_db = load_ingredients()
skin_types_db = load_skin_types()
body_parts_db = load_body_parts()

# --- 진단 정보 확인 ---
skin_type = st.session_state.get("skin_type")
fitzpatrick = st.session_state.get("fitzpatrick")
body_part = st.session_state.get("selected_body_part")
concerns = st.session_state.get("selected_concerns", [])

if not skin_type:
    st.warning("⚠️ 먼저 **피부진단** 페이지에서 피부 유형을 진단해 주세요.")
    st.stop()

st.success(f"🧬 피부 유형: **{skin_type}** | Fitzpatrick: **{fitzpatrick}**")
if body_part:
    bp_name = next((bp["name"] for bp in body_parts_db if bp["id"] == body_part), body_part)
    st.info(f"📍 분석 부위: **{bp_name}** | 고민: {', '.join(concerns) if concerns else '없음'}")

# --- 사용자 피부 타입 정보 로드 ---
user_skin = next((s for s in skin_types_db if s["type_code"] == skin_type), None)
avoid_ingredients_list = user_skin["avoid_ingredients"] if user_skin else []

# 성분 DB에서 해당 피부타입에 부적합한 성분 수집
skin_prefix = skin_type[:2]  # e.g. "DS", "OS", "DR", "OR"
ingredient_warnings = {}  # ingredient_name_ko -> reason
for ing in ingredients_db:
    for us in ing.get("unsuitable_skin_types", []):
        # "DS", "OS(고농도)" 같은 형태 처리
        base = us.replace("(고농도)", "").replace("(저농도)", "").strip()
        if base == skin_prefix or base == skin_type[:2]:
            ingredient_warnings[ing["name_ko"]] = {
                "reason": us,
                "caution": ing.get("caution", ""),
                "ewg": ing.get("ewg_grade", 1),
                "name_en": ing["name_en"],
                "bad_combos": ing.get("bad_combinations", [])
            }

st.markdown("---")

# --- 필터 옵션 ---
st.subheader("🔎 필터")
col1, col2, col3 = st.columns(3)

all_countries = sorted(set(p["country"] for p in products))
all_categories = sorted(set(p["category"] for p in products))
all_prices = ["전체", "저가", "중가", "고가", "프리미엄"]

with col1:
    sel_country = st.multiselect("🌍 국가", all_countries, default=all_countries)
with col2:
    sel_category = st.multiselect("📦 카테고리", all_categories, default=all_categories)
with col3:
    sel_price = st.selectbox("💰 가격대", all_prices)

st.markdown("---")

# --- 추천 점수 계산 ---
def compute_score(product):
    """추천 점수 산출 (0~100)"""
    score = 0
    
    # 1) 피부 타입 매칭 (40%)
    if skin_type in product.get("target_skin_types", []):
        score += 40
    else:
        # 부분 매칭: 첫 2글자(D/O + S/R) 일치
        for ts in product.get("target_skin_types", []):
            if ts[:2] == skin_type[:2]:
                score += 20
                break
    
    # 2) 고민 매칭 (30%)
    if concerns:
        matched = [c for c in concerns if c in product.get("target_concerns", [])]
        score += 30 * len(matched) / len(concerns) if concerns else 0
    
    # 3) 부위 매칭 (20%)
    if body_part:
        if body_part in product.get("target_body_parts", []):
            score += 20
    else:
        score += 10  # 부위 미선택 시 중립 점수
    
    # 4) 성분 안전성 (10%)
    has_warning = False
    for ki in product.get("key_ingredients", []):
        if ki in ingredient_warnings:
            has_warning = True
            break
    if not has_warning:
        score += 10
    
    return round(score, 1)


def check_contraindications(product):
    """사용 금지/주의 요인 분석"""
    warnings = []
    dangers = []
    
    # 1) 피부타입의 avoid_ingredients와 제품 성분 대조
    for ki in product.get("key_ingredients", []):
        for avoid in avoid_ingredients_list:
            # "레티놀(고농도)" → "레티놀" 매칭
            avoid_base = avoid.split("(")[0].strip()
            if avoid_base in ki or ki in avoid_base:
                dangers.append(f"🚫 **{ki}**: {skin_type} 피부 유형에서 피해야 할 성분 ({avoid})")
    
    # 2) 성분 DB의 unsuitable_skin_types 체크
    for ki in product.get("key_ingredients", []):
        if ki in ingredient_warnings:
            info = ingredient_warnings[ki]
            warnings.append(f"⚠️ **{ki}** ({info['name_en']}): {skin_prefix} 피부에 부적합 — {info['reason']}")
            if info["caution"]:
                warnings.append(f"  └ 주의: {info['caution']}")
    
    # 3) EWG 등급 경고 (6 이상)
    for ki in product.get("key_ingredients", []):
        for ing in ingredients_db:
            if ing["name_ko"] == ki and ing.get("ewg_grade", 1) >= 6:
                warnings.append(f"🟠 **{ki}**: EWG 위험 등급 {ing['ewg_grade']}/10")
    
    # 4) 임산부 주의 성분
    pregnancy_risk = ["레티놀", "살리실산", "벤조일퍼옥사이드"]
    for ki in product.get("key_ingredients", []):
        if ki in pregnancy_risk:
            warnings.append(f"🤰 **{ki}**: 임산부 사용 금지/주의 성분")
    
    # 5) 성분 간 상호작용 경고
    product_ings = product.get("key_ingredients", [])
    for ing_data in ingredients_db:
        if ing_data["name_ko"] in product_ings:
            for bad in ing_data.get("bad_combinations", []):
                for other_ki in product_ings:
                    bad_base = bad.split("(")[0].strip()
                    if other_ki != ing_data["name_ko"] and (bad_base in other_ki or other_ki in bad_base):
                        warnings.append(f"💥 **성분 충돌**: {ing_data['name_ko']} + {other_ki} — 동시 사용 주의 ({bad})")
    
    # 6) Fitzpatrick 기반 경고 (높은 피부색 유형에서 필링/미백 주의)
    if fitzpatrick in ["IV", "V", "VI"]:
        high_risk_ings = ["글리콜산", "코직산"]
        for ki in product.get("key_ingredients", []):
            if ki in high_risk_ings:
                warnings.append(f"🔆 **{ki}**: Fitzpatrick {fitzpatrick} 유형은 색소침착 악화 위험 — 전문의 상담 권장")
    
    return dangers, warnings


# --- 제품 분류 및 점수 산출 ---
scored_products = []
contraindicated_products = []

for p in products:
    # 필터 적용
    if p["country"] not in sel_country:
        continue
    if p["category"] not in sel_category:
        continue
    if sel_price != "전체" and p["price_range"] != sel_price:
        continue
    
    score = compute_score(p)
    dangers, warnings = check_contraindications(p)
    
    if dangers:
        contraindicated_products.append((p, score, dangers, warnings))
    else:
        scored_products.append((p, score, warnings))

# --- 추천 제품 표시 ---
scored_products.sort(key=lambda x: x[1], reverse=True)

st.subheader(f"✅ 추천 제품 ({len(scored_products)}개)")

if not scored_products:
    st.info("조건에 맞는 추천 제품이 없습니다. 필터를 조정해 보세요.")
else:
    for p, score, warnings in scored_products:
        # 점수에 따른 색상
        if score >= 70:
            badge = "🟢"
        elif score >= 40:
            badge = "🟡"
        else:
            badge = "⚪"
        
        with st.expander(f"{badge} {p['name']} — {p['brand']} ({p['country']}) | 적합도: {score}점"):
            col_a, col_b = st.columns([2, 1])
            with col_a:
                st.markdown(f"**{p['description']}**")
                st.markdown(f"• **카테고리**: {p['category']}")
                st.markdown(f"• **가격대**: {p['price_range']}")
                st.markdown(f"• **주요 성분**: {', '.join(p['key_ingredients'])}")
                st.markdown(f"• **대상 고민**: {', '.join(p.get('target_concerns', []))}")
                st.markdown(f"• **적용 부위**: {', '.join(p.get('target_body_parts', []))}")
            
            with col_b:
                st.metric("적합도 점수", f"{score}/100")
                # 점수 구성
                st.caption("피부타입 40% + 고민 30% + 부위 20% + 안전성 10%")
            
            if warnings:
                st.markdown("---")
                st.markdown("#### ⚠️ 사용 시 주의사항")
                for w in warnings:
                    st.markdown(w)

# --- 사용 금지 권고 제품 ---
if contraindicated_products:
    st.markdown("---")
    st.subheader(f"🚫 사용 금지 권고 제품 ({len(contraindicated_products)}개)")
    st.error("아래 제품은 현재 피부 유형에 부적합한 성분이 포함되어 있어 **사용을 권장하지 않습니다.**")
    
    contraindicated_products.sort(key=lambda x: len(x[2]), reverse=True)
    
    for p, score, dangers, warnings in contraindicated_products:
        with st.expander(f"🚫 {p['name']} — {p['brand']} ({p['country']})"):
            st.markdown(f"**{p['description']}**")
            st.markdown(f"• **주요 성분**: {', '.join(p['key_ingredients'])}")
            
            st.markdown("#### 🚫 금지 사유")
            for d in dangers:
                st.markdown(d)
            
            if warnings:
                st.markdown("#### ⚠️ 추가 주의사항")
                for w in warnings:
                    st.markdown(w)
            
            st.markdown("---")
            st.markdown("💡 **대안 찾기**: 위 필터에서 성분을 고려하여 다른 제품을 검색해 보세요.")

# --- 하단 안내 ---
st.markdown("---")
st.markdown("### 📋 추천 기준 안내")
st.markdown("""
| 요소 | 비중 | 설명 |
|------|------|------|
| 피부 유형 매칭 | 40% | Baumann 피부 유형과 제품 대상 유형 일치도 |
| 고민 매칭 | 30% | 선택한 피부 고민과 제품 효능 일치도 |
| 부위 매칭 | 20% | 선택한 신체 부위와 제품 적용 부위 일치도 |
| 성분 안전성 | 10% | 피부 유형에 부적합한 성분 포함 여부 |
""")

st.markdown("""
#### 🚫 사용 금지 판정 기준
- **피부 유형별 금기 성분**: Baumann 분류 기반 피해야 할 성분 포함 시
- **EWG 위험 등급**: 안전 등급 6 이상의 고위험 성분 포함 시
- **임산부 금기 성분**: 레티놀, 살리실산, 벤조일퍼옥사이드 등
- **성분 간 충돌**: 동일 제품 내 상극 성분 조합
- **Fitzpatrick 유형 고려**: 피부색이 어두운 유형(IV~VI)의 필링/미백 성분 주의
""")

st.caption("※ 본 추천은 참고용이며, 심각한 피부 질환이 있을 경우 전문 피부과 상담을 권장합니다.")
