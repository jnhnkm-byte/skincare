"""
JH 스마트 스킨케어 - 데스크톱 런처
더블클릭으로 실행합니다.
"""
import subprocess, sys, socket, webbrowser, time, os

def find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]

def main():
    port = find_free_port()
    app_dir = os.path.dirname(os.path.abspath(__file__))
    app_py = os.path.join(app_dir, "app.py")
    
    print(f"JH Smart Skincare launching on port {port}...")
    print(f"Open http://localhost:{port} in your browser")
    
    proc = subprocess.Popen([
        sys.executable, "-m", "streamlit", "run", app_py,
        "--server.port", str(port),
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false",
    ])
    
    time.sleep(3)
    webbrowser.open(f"http://localhost:{port}")
    
    try:
        proc.wait()
    except KeyboardInterrupt:
        proc.terminate()

if __name__ == "__main__":
    main()
